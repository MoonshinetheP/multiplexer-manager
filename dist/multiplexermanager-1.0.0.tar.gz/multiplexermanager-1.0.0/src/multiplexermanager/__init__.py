"""
multiplexer-manager pip version

"""

from . import multiplexermanager

__version__ = "1.0.3"
__author__ = 'Steven Linfield'

__all__ = ['multiplexermanager']
