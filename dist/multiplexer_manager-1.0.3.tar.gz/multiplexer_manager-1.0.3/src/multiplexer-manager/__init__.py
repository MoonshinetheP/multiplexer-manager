"""
multiplexer-manager pip version

"""

from .multiplexermanager import *

__version__ = "1.0.3"
__author__ = 'Steven Linfield'

__all__ = ['multiplexermanager']
